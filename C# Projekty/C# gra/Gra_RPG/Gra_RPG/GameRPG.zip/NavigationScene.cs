﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Gra_RPG
{
    public class NavigationScene : Scene // może kiedyś się przyda...
    {
        public NavigationScene(Game game): base(game)
        {

        }
        public override void Run()
        {
           
           
            
                
                
           
        }
    }
}
