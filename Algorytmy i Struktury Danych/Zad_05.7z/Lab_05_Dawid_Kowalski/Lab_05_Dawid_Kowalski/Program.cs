﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_05_Dawid_Kowalski
{
    public class ElementListy2 // lista dwukierunkowa
    {
        public double Wartość;
        public ElementListy2 Poprzedni;
        public ElementListy2 Następny;
        private double x;
        private ElementListy2 Korzeń;
        private int i;
        private int tab = 0;
        public ElementListy2 Nowy;

       
        public ElementListy2(double x, ElementListy2 Poprzednik)
        {
            Poprzedni = Poprzednik;
            Następny = null;
            Wartość = x;
            this.x = x;
            Nowy = null;
        }
        public void DopiszDoListy(double x)
        {
            if (Następny != null)
            {
                Następny.DopiszDoListy(x);
                tab++;
            }
            else
            {
                Następny = new ElementListy2(x, this);
                tab++;
            }

            if (this.Wartość < x)
            {
                if (this.Następny != null)
                {
                    if (Następny.Wartość < x)
                    {
                        Następny = Następny.Następny;
                    }
                    else
                    {
                        Nowy = new ElementListy2(x, this);
                        Nowy.Następny = this.Następny;
                        if (Nowy.Następny != null)
                        {
                            Nowy.Następny.Poprzedni = Nowy;
                        }
                        Następny = Nowy;
                        Nowy = null;
                    }
                }
            }

            if (this.Wartość == x)
            {
                Nowy = new ElementListy2(x, this);
                Nowy.Następny = this.Następny;
                if (Nowy.Następny != null)
                {
                    Nowy.Następny.Poprzedni = Nowy;
                }
                this.Następny = Nowy;
                Nowy = null;
            }
        }

        public void DopiszDoKońca(double x)
        {
            if (Następny == null)
            {
                Następny = new ElementListy2(x, this);
            }
            else
            {
                Następny.DopiszDoKońca(x);
            }
        }

        public void DopiszDoPoczątku(double x)
        {
            if (Poprzedni == null)
            {
                ElementListy2 nowyPoczątek = new ElementListy2(x, null);
                this.Poprzedni = nowyPoczątek;
                nowyPoczątek.Następny = this;
            }
            else
            {
                Poprzedni.DopiszDoPoczątku(x);
            }
        }

        public void PrzeglądajDoPrzodu()
        {
            Console.Write( Wartość);
            Console.Write(", ");
            if (Następny != null) Następny.PrzeglądajDoPrzodu();
        }

        public void PrzeglądajDoTyłu()
        {
            Console.Write(Wartość);
            Console.Write(", ");
            if (Poprzedni != null) Poprzedni.PrzeglądajDoTyłu();
        }

        public void Delete()
        {
            if (Następny != null)
            {
                if (Następny.Następny != null)
                {
                    Następny.Delete();
                }
                Następny = null;
            }
        }

        public bool CzyJest(double x, double dok)
        {
            ElementListy2 bieżący = this;
            bool czy_jest = false;
            double min = x - dok;
            double max = x + dok;

            while (bieżący.Poprzedni != null)
            {
                bieżący = bieżący.Poprzedni;
            }

            do
            {
                if (bieżący.Wartość >= min && bieżący.Wartość <= max)
                {
                    czy_jest = true;
                    break;
                }

                bieżący = bieżący.Następny;

            } while (czy_jest == false && bieżący != null);

            return czy_jest;
        }


        
        public ElementListy2 Sort()
        {
            
            if (this.Następny == null)
            {
                return this;
            }

            ElementListy2 posortowanaLista = null;
            ElementListy2 obecny = this;

            while (obecny != null)
            {
                ElementListy2 następnyElement = obecny.Następny;

                
                obecny.Następny = null;
                obecny.Poprzedni = null;

                
                if (posortowanaLista == null || obecny.Wartość > posortowanaLista.Wartość)
                {
                   
                    obecny.Następny = posortowanaLista;
                    if (posortowanaLista != null)
                    {
                        posortowanaLista.Poprzedni = obecny;
                    }
                    posortowanaLista = obecny;
                }
                else
                {
                   
                    ElementListy2 temp = posortowanaLista;
                    while (temp.Następny != null && temp.Następny.Wartość > obecny.Wartość)
                    {
                        temp = temp.Następny;
                    }

                   
                    obecny.Następny = temp.Następny;
                    if (temp.Następny != null)
                    {
                        temp.Następny.Poprzedni = obecny;
                    }
                    obecny.Poprzedni = temp;
                    temp.Następny = obecny;
                }

                obecny = następnyElement;
            }

            return posortowanaLista;
        }
    }


    class Program
    {
       
        static ElementListy2 ZnajdźGłowę(ElementListy2 dowolnyElement)
        {
            if (dowolnyElement == null) return null;
            ElementListy2 głowa = dowolnyElement;
            while (głowa.Poprzedni != null)
            {
                głowa = głowa.Poprzedni;
            }
            return głowa;
        }

        static void Main(string[] args)
        {
            double x = 10.5;
            ElementListy2 Głowa = new ElementListy2(x, null);
            double[] tab = { -10, 50, -6, 40, 0, 1, 2, 30, 9 };

          
            for (int i = 0; i < tab.Length; i++)
            {
                if (tab[i] <= 0)
                {
                    Głowa.DopiszDoPoczątku(tab[i]);
                }
                else
                {
                    ElementListy2 aktualnaGłowa = ZnajdźGłowę(Głowa);
                    aktualnaGłowa.DopiszDoKońca(tab[i]);
                }
            }

            // Znajdowanie głowy
            ElementListy2 faktycznaGłowa = ZnajdźGłowę(Głowa);

            Console.WriteLine("--- Lista przed sortowaniem ---");
            faktycznaGłowa.PrzeglądajDoPrzodu();
            Console.WriteLine("------------------");

            // Sortowanie
            faktycznaGłowa = faktycznaGłowa.Sort();

            Console.WriteLine("--- Lista po sortowaniu Malejącym (od największego do najmniejszego) ---");
            faktycznaGłowa.PrzeglądajDoPrzodu();
            Console.WriteLine("------------------");

            Console.WriteLine("Test CzyJest:");
            Console.WriteLine("Czy jest 50 ......." + faktycznaGłowa.CzyJest(50.0, 0.1));
            Console.WriteLine("Czy jest 7 ......." + faktycznaGłowa.CzyJest(7.0, 0.1));
            Console.ReadKey();

        }
    }
}