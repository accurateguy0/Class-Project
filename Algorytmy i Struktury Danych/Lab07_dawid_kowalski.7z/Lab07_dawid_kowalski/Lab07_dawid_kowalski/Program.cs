﻿using System;

namespace HeapSort
{
    class HeapSort
    {
        public long IterationCount { get; private set; }

        public void Sort(int[] array)
        {
            IterationCount = 0;
            int n = array.Length;

            for (int i = n / 2 - 1; i >= 0; i--)
            {
                IterationCount++;
                Heapify(array, n, i);
            }

            for (int i = n - 1; i > 0; i--)
            {
                IterationCount++;
                int temp = array[0];
                array[0] = array[i];
                array[i] = temp;

                Heapify(array, i, 0);
            }
        }

        private void Heapify(int[] array, int n, int i)
        {
            int largest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < n)
            {
                IterationCount++;
                if (array[left] > array[largest])
                {
                    largest = left;
                }
            }

            if (right < n)
            {
                IterationCount++;
                if (array[right] > array[largest])
                {
                    largest = right;
                }
            }

            if (largest != i)
            {
                int swap = array[i];
                array[i] = array[largest];
                array[largest] = swap;

                Heapify(array, n, largest);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int[] sizes = { 10, 100, 1000, 10000, 100000 };

            Console.WriteLine("{0,10} | {1,15} | {2,15}", "N", "Iteracje", "N * log2(N)");
            Console.WriteLine(new string('-', 45));

            foreach (int n in sizes)
            {
                int[] data = GenerateRandomArray(n);
                HeapSort hs = new HeapSort();

                hs.Sort(data);

                double theoretical = n * Math.Log(n, 2);
                Console.WriteLine("{0,10} | {1,15} | {2,15:F0}", n, hs.IterationCount, theoretical);
            }
        }

        static int[] GenerateRandomArray(int size)
        {
            Random rand = new Random();
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = rand.Next(0, 100000);
            }
            return array;
        }
    }
}