﻿using System;

namespace Zad06_Dawid_Kowalski
{
    // 1. Definicja pojedynczego punktu w drzewie
    public class Wierzcholek
    {
        public int Wartosc { get; set; }
        public Wierzcholek(int wartosc)
        {
            Wartosc = wartosc;
        }
    }

    // 2. Definicja drzewa opartego na tablicy
    public class DrzewoBinarne
    {
        private Wierzcholek[] tablica;
        private int rozmiar;

        public DrzewoBinarne(int pojemnosc)
        {
            tablica = new Wierzcholek[pojemnosc];
            rozmiar = pojemnosc;
        }

        public void Dodaj(int x)
        {
            for (int i = 0; i < rozmiar; i++)
            {
                if (tablica[i] == null)
                {
                    tablica[i] = new Wierzcholek(x);
                    Console.WriteLine("Dodano " + x + " na indeksie " + i);
                    return;
                }
            }
            Console.WriteLine("Drzewo jest pełne!");
        }

        public void PokazTablice()
        {
            Console.WriteLine("\nZawartość tablicy:");
            for (int i = 0; i < tablica.Length; i++)
            {
                if (tablica[i] != null)
                    Console.WriteLine("Indeks " + i + ": " + tablica[i].Wartosc);
                else
                    Console.WriteLine("Indeks " + i + ": [Puste]");
            }
        }

        public void InOrder(int indeks = 0)
        {
            // Zabezpieczenie przed NullReferenceException i wyjściem poza tablicę
            if (indeks >= rozmiar || tablica[indeks] == null) return;

            InOrder(2 * indeks + 1); // Lewe dziecko
            Console.Write(tablica[indeks].Wartosc + " "); // Korzeń
            InOrder(2 * indeks + 2); // Prawe dziecko
        }
    }

    // 3. Główna klasa uruchomieniowa (tylko jedna w całym projekcie!)
    class Program
    {
        static void Main(string[] args)
        {
            DrzewoBinarne drzewo = new DrzewoBinarne(15);

            drzewo.Dodaj(10);
            drzewo.Dodaj(5);
            drzewo.Dodaj(15);
            drzewo.Dodaj(2);

            Console.WriteLine("\nPrzejście InOrder:");
            drzewo.InOrder();
            Console.WriteLine();

            drzewo.PokazTablice();

            Console.WriteLine("\nNaciśnij dowolny klawisz, aby wyjść...");
            Console.ReadKey();
        }
    }
}