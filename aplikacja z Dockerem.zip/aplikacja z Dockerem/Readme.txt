Aby to uruchomić:

docker build -t note-app .

Uruchom kontener:

docker run -d -p 3000:3000 cyber-monitor

Wejdź w przeglądarce na: http://localhost:3000

Re-build kontenera jakbyś chciał poprawić coś:

# Zatrzymaj wszystkie kontenery (nawet te w tle)
podman stop -a

# Usuń wszystkie kontenery (żeby zwolnić nazwy i porty)
podman rm -a

podman build -t note-app .
podman run -d -p 3000:3000 --name note-app --rm note-app
