const express = require('express'); // framework do tworzenia serwera
const fileUpload = require('express-fileupload'); // middleware do obsługi uploadu plików
const path = require('path'); // moduł do pracy ze ścieżkami plików
const sqlite3 = require('sqlite3').verbose();  // baza danych SQLite
const jwt = require('jsonwebtoken'); // moduł do obsługi JSON Web Tokenów (JWT) - do autoryzacji użytkowników
const fs = require('fs'); // moduł do pracy z systemem plików (używany do tworzenia katalogu uploadów)

const app = express(); // Inicjalizacja aplikacji Express
const SECRET_KEY = "tajny_klucz_hakera"; //klucz do podpisywania JWT 
const db = new sqlite3.Database(path.join(__dirname, 'database.db')); // Inicjalizacja bazy danych SQLite, plik będzie w tym samym katalogu co server.js

const uploadDir = path.join(__dirname, 'public/uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

app.use(express.json()); // Middleware do parsowania JSON w ciele żądań
app.use(express.static('public')); // Middleware do serwowania statycznych plików z katalogu "public"
app.use(fileUpload());  // Middleware do obsługi uploadu plików

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
    db.run("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, title TEXT, content TEXT)");
    db.run("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, from_user TEXT, to_user TEXT, content TEXT, file_url TEXT)");
}); // Tworzenie tabel w bazie danych, jeśli jeszcze nie istnieją - tabela "users" do przechowywania użytkowników, "notes" do notatek i "messages" do wiadomości między użytkownikami

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).send("Brak tokena");
    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).send("Token nieważny");
        req.user = user;
        next();
    }); 
}; // Middleware do autoryzacji - sprawdza, czy w nagłówku "Authorization" jest token JWT, weryfikuje go i jeśli jest poprawny, dodaje dane użytkownika do obiektu "req.user" i przechodzi do następnego middleware lub trasy. Jeśli token jest nieobecny lub nieważny, zwraca błąd 401 lub 403.

// --- API UŻYTKOWNIKÓW ---
app.get('/api/users', authenticateToken, (req, res) => {
    db.all("SELECT id, username FROM users", [], (err, rows) => {
        if (err) return res.status(500).json({ error: "Błąd bazy" });
        res.json(rows);
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
    db.get(query, [], (err, user) => {
        if (err || !user) return res.status(401).json({ error: "Błąd" });
        const token = jwt.sign({ userId: user.id, username: user.username }, SECRET_KEY, { expiresIn: '1h' });
        res.json({ token });
    });
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    db.run("INSERT INTO users (username, password) VALUES (?, ?)", [username, password], () => res.json({ ok: true }));
});

// --- API NOTATEK ---
app.get('/api/notes', authenticateToken, (req, res) => {
    db.all("SELECT * FROM notes WHERE user_id = ?", [req.user.userId], (err, rows) => res.json(rows));
});

app.post('/api/notes', authenticateToken, (req, res) => {
    const { title, content } = req.body;
    if (!title || title.trim() === "") return res.status(400).json({ error: "MUSISZ PODAĆ TYTUŁ!" });
    db.run("INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)", [req.user.userId, title, content], () => res.json({ ok: true }));
});

app.delete('/api/notes/:id', authenticateToken, (req, res) => {
    db.run("DELETE FROM notes WHERE id = ? AND user_id = ?", [req.params.id, req.user.userId], () => res.json({ ok: true }));
});

app.put('/api/notes/:id', authenticateToken, (req, res) => {
    const { title, content } = req.body;
    
    // Walidacja tytułu również przy edycji
    if (!title || title.trim() === "") {
        return res.status(400).json({ error: "Tytuł nie może być pusty!" });
    }

    db.run("UPDATE notes SET title = ?, content = ? WHERE id = ? AND user_id = ?", 
        [title, content, req.params.id, req.user.userId], function(err) {
            if (err) return res.status(500).json({ error: "Błąd bazy danych" });
            res.json({ message: "Zaktualizowano pomyślnie!" });
        });
});

// --- API WIADOMOŚCI I PLIKÓW ---
app.post('/api/upload', authenticateToken, (req, res) => {
    if (!req.files) return res.status(400).send('Brak pliku');
    let file = req.files.attachment;
    let fileName = Date.now() + "_" + file.name;
    file.mv(path.join(uploadDir, fileName), (err) => {
        if (err) return res.status(500).send(err);
        res.json({ url: '/uploads/' + fileName });
    });
});

app.post('/api/messages', authenticateToken, (req, res) => {
    const { to_user, content, file_url } = req.body;
    db.run("INSERT INTO messages (from_user, to_user, content, file_url) VALUES (?, ?, ?, ?)", 
        [req.user.username, to_user, content, file_url], () => res.json({ ok: true }));
});

app.get('/api/messages', authenticateToken, (req, res) => {
    db.all("SELECT * FROM messages WHERE to_user = ? OR from_user = ?", [req.user.username, req.user.username], (err, rows) => res.json(rows));
});

app.get('/api/messages/:id', authenticateToken, (req, res) => {
    db.get("SELECT * FROM messages WHERE id = ?", [req.params.id], (err, row) => res.json(row));
});

app.delete('/api/messages/:id', authenticateToken, (req, res) => {
    db.run("DELETE FROM messages WHERE id = ? AND (to_user = ? OR from_user = ?)", 
    [req.params.id, req.user.username, req.user.username], () => res.json({ ok: true }));
});

// --- ROUTING ---
app.get('/notes', (req, res) => res.sendFile(path.join(__dirname, 'public', 'notes.html')));
app.get('/messages', (req, res) => res.sendFile(path.join(__dirname, 'public', 'messages.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(3000, '0.0.0.0', () => console.log('Serwer hakerski działa na porcie 3000'));