const token = localStorage.getItem('token');
const contentInput = document.getElementById('content');
const livePreview = document.getElementById('livePreview');
const previewArea = document.getElementById('previewArea');

if (!token) {
    window.location.href = '/';
} else {
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        document.getElementById('userDisplay').innerText = payload.username;
    } catch (e) { logout(); }
}

function renderContent(text) {
    if (!text) return '';

    // Celowo NIE używamy .replace(/</g, "&lt;"), żeby przeglądarka czytała HTML
    let processed = text;

    const imgRegex = /(https?:\/\/[^\s]+(?:\.jpg|\.jpeg|\.gif|\.png|\.webp))/gi;
    processed = processed.replace(imgRegex, (url) => {
        return `<img src="${url}" class="max-w-full h-auto border-2 border-black my-2 mx-auto block shadow-md">`;
    });

    return processed.replace(/\n/g, '<br>');
}
// Podgląd na żywo
contentInput.addEventListener('input', () => {
    if (contentInput.value.length > 0) {
        previewArea.classList.remove('hidden');
        livePreview.innerHTML = renderContent(contentInput.value);
    } else {
        previewArea.classList.add('hidden');
    }
});

async function loadNotes() {
    const res = await fetch('/api/notes', { headers: { 'Authorization': `Bearer ${token}` } });
    const notes = await res.json();
    const list = document.getElementById('notesList');
    list.innerHTML = notes.map(n => `
        <div class="bg-white border-2 border-black p-2 flex justify-between items-center hover:bg-gray-100 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            <div onclick="openNote(${n.id}, \`${n.title.replace(/`/g, "\\`")}\`, \`${n.content.replace(/`/g, "\\`")}\`)" class="cursor-pointer font-bold uppercase truncate flex-grow mr-4">
                ${n.title}
            </div>
            <button onclick="deleteNote(${n.id})" class="text-red-600 font-bold border border-red-600 px-2 hover:bg-red-50">X</button>
        </div>
    `).join('') || '<p class="text-center text-xs uppercase text-gray-500">Brak notatek</p>';
} // wczytuje notatki 

function openNote(id, title, content) {
    document.getElementById('noteId').value = id;
    document.getElementById('title').value = title;
    document.getElementById('content').value = content;

    previewArea.classList.remove('hidden');
    livePreview.innerHTML = renderContent(content);

    const saveBtn = document.getElementById('saveBtn');
    saveBtn.innerText = "ZAKTUALIZUJ ZMIANY";
    saveBtn.onclick = updateNote;
    document.getElementById('cancelBtn').classList.remove('hidden');
} // otwiera notatkę do edycji

async function saveNote() {

    const titleElement = document.getElementById('title');
    const contentElement = document.getElementById('content');

    if (!titleElement) { // jeśli nie ma elementu o ID 'title' to go nie zapisuje
        console.error(" Nie znaleziono elementu o ID 'title'!");
        return;
    }

    const title = titleElement.value.trim();
    const content = contentElement.value;

    // WALIDACJA
    if (title === "") {
        console.log("Walidacja nieudana: brak tytułu");
        alert("Wpisz tytuł notatki");
        titleElement.focus(); // Ustawienie kursora w polu tytułu
        return;
    }

    const res = await fetch('/api/notes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ title, content }) // wysyła notatkę i token
    });

    if (res.ok) { // jeśli notatka została zapisana pomyślnie
        resetForm();
        loadNotes();
    } else { // inaczej wyświetla błąd
        const data = await res.json();
        alert(data.error);
    }
}
async function updateNote() {
    const id = document.getElementById('noteId').value;
    const title = document.getElementById('title').value;
    const content = document.getElementById('content').value;

    // Walidacja tytułu
    if (!title.trim()) {
        alert("Wpisz tytuł notatki");
        return;
    }

    const res = await fetch(`/api/notes/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title, content })
    }); // aktualizuje notatkę i token

    if (res.ok) { // jeśli notatka została zaktualizowana pomyślnie
        alert("Zaktualizowano notatkę");
        resetForm();
        loadNotes();
    } else {
        const errData = await res.json();
        alert(errData.error);
    }
}

async function deleteNote(id) {
    if (confirm("Usunąć?")) {
        await fetch(`/api/notes/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
        loadNotes();
    }
}

function resetForm() { // resetuje formularz notatki
    document.getElementById('noteId').value = '';
    document.getElementById('title').value = '';
    document.getElementById('content').value = '';
    previewArea.classList.add('hidden');
    const saveBtn = document.getElementById('saveBtn');
    saveBtn.innerText = "ZAPISZ";
    saveBtn.onclick = saveNote;
    document.getElementById('cancelBtn').classList.add('hidden');
}

function logout() { // wylogowuje użytkownika
    localStorage.removeItem('token');
    window.location.href = '/';
}

loadNotes();