document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault(); // zapobiega przeładowaniu strony
    const msg = document.getElementById('msg'); // pobiera komunikat

    const res = await fetch('/register', { // wysyła zapytanie do serwera, a await czeka na odpowiedź, tak aby zapytanie nie zatknęło się
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ // musimy dać json stringify aby serwer mógł odczytać dane, bo jest w formie json, a serwer odczytuje string
            username: document.getElementById('username').value,
            password: document.getElementById('password').value
        })
    });

    const data = await res.json(); // pobiera odpowiedź od serwera
    if (res.ok) { // jeśli odpowiedź jest ok
        alert("Rejestracja udana! Przekierowuję do logowania.");
        window.location.href = '/'; // Powrót do logowania
    } else { // jeśli odpowiedź nie jest ok
        msg.innerText = data.error || data.message; // wyświetla błąd
        msg.style.color = "red"; // ustawia kolor błędu na czerwony
    }
});