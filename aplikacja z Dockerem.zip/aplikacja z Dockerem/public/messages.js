const token = localStorage.getItem('token');
let myUsername = "";

if (token) {
    const payload = JSON.parse(atob(token.split('.')[1]));
    myUsername = payload.username;
}

function toggleCreateForm() {
    document.getElementById('createForm').classList.toggle('hidden');
}

async function loadUsers() {
    const res = await fetch('/api/users', { headers: { 'Authorization': `Bearer ${token}` } });
    const users = await res.json();
    document.getElementById('userSelect').innerHTML = users
        .filter(u => u.username !== myUsername)
        .map(u => `<option value="${u.username}">${u.username}</option>`).join('');
}

async function loadMessages() {
    const res = await fetch('/api/messages', { headers: { 'Authorization': `Bearer ${token}` } });
    const msgs = await res.json();
    const list = document.getElementById('messagesList');

    list.innerHTML = msgs.map(m => {
        const isSent = m.from_user === myUsername;
        // Sami robimy skrót treści, żeby uniknąć "undefined"
        const preview = m.content.replace(/<[^>]*>/g, '').substring(0, 20);

        return `
            <div onclick="openMessage(${m.id})" class="cursor-pointer bg-white border-2 border-black p-3 hover:bg-gray-100 flex justify-between shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <div>
                    <p class="text-[10px] font-bold uppercase">${isSent ? 'DO: ' + m.to_user : 'OD: ' + m.from_user}</p>
                    <p class="text-xs text-gray-600">${preview}...</p>
                </div>
                <span class="text-[10px] font-bold ${isSent ? 'text-blue-500' : 'text-green-500'}">${isSent ? 'WYSŁANA' : 'ODEBRANA'}</span>
            </div>
        `;
    }).join('') || '<p class="text-center text-xs uppercase opacity-50 py-10">Brak wiadomości</p>';
}

async function openMessage(id) {
    const res = await fetch(`/api/messages/${id}`, { headers: { 'Authorization': `Bearer ${token}` } });
    const msg = await res.json();

    document.getElementById('modalFrom').innerText = `Od: ${msg.from_user}`;
    // Tu jest podatność XSS
    document.getElementById('modalContent').innerHTML = msg.content;
    if (msg.file_url) {
        document.getElementById('modalContent').innerHTML += `
        <div class="mt-4 p-2 border-t font-bold text-xs">
            Załącznik: <a href="${msg.file_url}" target="_blank" class="text-blue-600 underline">POBIERZ PLIK</a>
        </div>
    `;
    }

    document.getElementById('deleteBtn').onclick = () => deleteMsg(id);
    document.getElementById('msgModal').classList.remove('hidden');
}

async function deleteMsg(id) {
    if (confirm("Usunąć?")) {
        await fetch(`/api/messages/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
        closeModal();
        loadMessages();
    }
}

function closeModal() {
    document.getElementById('msgModal').classList.add('hidden');
    document.getElementById('modalContent').innerHTML = "";
}

async function sendMessage() {
    const to_user = document.getElementById('userSelect').value;
    const content = document.getElementById('msgContent').value;
    const fileInput = document.getElementById('fileInput');
    if (!to_user || to_user === "") {
        alert("Wybierz odbiorcę");
        return; // Przerywa funkcję jeśli nie wybrano odbiorcy
    }

    // Checkuje czy wiadomość nie jest pusta
    if (!content.trim()) {
        alert("BŁĄD: Nie można wysłać pustej wiadomości!");
        return;
    }

    let file_url = "";

    if (fileInput.files.length > 0) { // jeśli jest plik to go wysyła
        const formData = new FormData();
        formData.append('attachment', fileInput.files[0]);
        const uploadRes = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        const uploadData = await uploadRes.json();
        file_url = uploadData.url;
    }

    await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ to_user, content, file_url })
    }); // wysyła wiadomość
    alert("Wiadomość wysłana!");
    location.reload(); // odświeża stronę
}

loadUsers();
loadMessages();