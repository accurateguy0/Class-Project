document.getElementById('authForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            username: document.getElementById('username').value,
            password: document.getElementById('password').value
        })
    });

    const data = await res.json();
    if (res.ok) {
        localStorage.setItem('token', data.token); // Zapisujemy JWT
        window.location.href = '/notes';
    } else {
        document.getElementById('msg').innerText = data.error;
    }
});